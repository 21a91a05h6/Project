// import images from all-images/blog-img directory
import img01 from "../all-images/blog-img/blog-1.jpg";
import img02 from "../all-images/blog-img/blog-2.jpg";
import img03 from "../all-images/blog-img/blog-3.jpg";

const blogData = [
  {
    id: 1,
    title: "The best way to drive cars",
    author: "Muhib",
    date: "12 Dec, 2020",
    time: "9pm",
    imgUrl: img01,
    description:
      " Driving is an essential skill that opens up a world of possibilities, allowing us to explore new places, connect with others, and experience the thrill of the open road. While it may seem daunting at first, with practice and dedication, anyone can become a competent and confident driver. In this ongoing blog series, we'll delve into the intricacies of driving, providing valuable insights and tips to help you navigate the roads safely and skillfully. Before embarking on any journey, it's crucial to ensure that both you and your vehicle are ready for the task at hand. This involves being well-rested, alert, and free from any distractions that could impair your judgment or reaction time. Avoid driving under the influence of alcohol or any substances that could compromise your ability to control the vehicle. Your car is your partner on the road, and its condition directly impacts your safety and driving experience. Regular maintenance is essential to ensure that your vehicle is in top shape, minimizing the risk of breakdowns or malfunctions. Check tire pressure, fluid levels, and overall mechanical integrity before hitting the road. Traffic laws exist to maintain order and safety on the roads. Familiarize yourself with the rules and regulations governing your area, including speed limits, lane markings, and traffic signs. Abiding by these guidelines not only protects you but also ensures the safety of other road users.",
    quote:
      "The best way to drive a car is to drive with a calm and focused mind, a respectful heart, and a vigilant eye.",
  },

  {
    id: 2,
    title: "If your car battery is down",
    author: "Muhib",
    date: "7 Feb, 2021",
    time: "10pm",
    imgUrl: img02,
    description:
      " The dreaded click... click... click... of a car that refuses to start is a sound no driver wants to hear. A dead car battery can bring your journey to an abrupt halt, leaving you stranded and frustrated. But don't despair! With a bit of knowledge and preparation, you can handle this common automotive hiccup and get back on the road in no time. If you're dealing with a dead battery, jump-starting your car is a quick and effective way to get it running again. However, it's important to follow the correct procedure to avoid damaging your car's electrical system or causing injury. If your interior lights are dim or completely unresponsive when you turn the key, it's a strong indication that your battery is drained. When you turn the key, does the engine crank slowly or not at all? This is a clear sign that your battery lacks the power to start the engine. If your check engine light is illuminated, it could indicate a problem with the alternator, which is responsible for charging the battery. You'll need jumper cables and a car with a working battery to provide the jump-start. Park the cars close enough for the jumper cables to reach, ensuring they don't touch. Turn off both cars and engage the parking brakes. Start the car with the working battery and let it run for a few minutes to charge the dead battery. Attempt to start the car with the dead battery. If it doesn't start, let it charge for a few more minutes and try again.",
    quote:
      "A dead car battery is a reminder that even the most reliable machines need proper care and attention. Just as we nurture our own energy levels, we must also tend to the heart of our vehicles, ensuring they have the power to carry us forward.",
  },

  {
    id: 3,
    title: "The best way to give trip",
    author: "Muhib",
    date: "26 May, 2023",
    time: "6pm",
    imgUrl: img03,
    description:
      " Traveling is an enriching experience that broadens our horizons, sparks new passions, and creates unforgettable memories. But planning a trip that perfectly aligns with your interests, preferences, and budget can be a daunting task. Here's a comprehensive guide to crafting the best possible trip, ensuring an adventure that's tailored to your unique desires. Before delving into destinations and itineraries, take a moment to reflect on your travel style. Are you an adventurous soul seeking adrenaline-pumping experiences, or do you prefer leisurely explorations of cultural and historical gems? Do you crave the excitement of bustling cities, or do you yearn for the tranquility of natural landscapes? Understanding your travel preferences will help narrow down your options and guide your planning process. Financial considerations play a crucial role in shaping your travel plans. Determine a realistic budget that accounts for transportation, accommodation, activities, meals, and any unexpected expenses. Researching average costs for your chosen destination will help you allocate funds effectively and avoid financial surprises. With a plethora of options available, selecting the ideal destination can be overwhelming. Consider factors such as climate, cultural attractions, natural wonders, and accessibility. Research the destination's peak and off-season periods to align your trip with your budget and preferences. Immerse yourself in the local culture by venturing beyond tourist hotspots. Explore local markets, sample authentic cuisine, and engage with the community. Learn a few basic phrases in the local language to enhance your interactions.",
    quote:
      "The best way to give a trip is not to hand someone a ticket, but to open a door to a world of possibilities.",
  },
];

export default blogData;
