// import all images from assets/images directory
import img01 from "../all-images/cars-img/nissan-offer.png";
import img02 from "../all-images/cars-img/offer-toyota.png";
import img03 from "../all-images/cars-img/bmw-offer.png";
import img04 from "../all-images/cars-img/nissan-offer.png";
import img05 from "../all-images/cars-img/offer-toyota.png";
import img06 from "../all-images/cars-img/mercedes-offer.png";
import img07 from "../all-images/cars-img/toyota-offer-2.png";
import img08 from "../all-images/cars-img/mercedes-offer.png";

const carData = [
  {
    id: 1,
    brand: "Nissan",
    rating: 112,
    carName: "Nissan Magnite",
    imgUrl: img01,
    model: "Model 3",
    price: 5000,
    speed: "20kmpl",
    gps: "GPS Navigation",
    seatType: "Heated seats",
    automatic: "Automatic",
    description:
      "The Nissan Magnite is a subcompact SUV that has captured the attention of urban explorers and adventurous spirits alike. Its bold design, impressive performance, and advanced technology make it a compelling choice for those seeking a stylish and practical city companion.",
  },

  {
    id: 2,
    brand: "Toyota",
    rating: 102,
    carName: "Toyota Camry",
    imgUrl: img02,
    model: "Model-2022",
    price: 5000,
    speed: "20kmpl",
    gps: "GPS Navigation",
    seatType: "Heated seats",
    automatic: "Automatic",
    description:
      " The Toyota Camry is a mid-size sedan that has long been synonymous with reliability, comfort, and a refined driving experience. It has consistently been a top-selling car in its segment, appealing to a wide range of drivers seeking a dependable and well-rounded vehicle.",
  },

  {
    id: 3,
    brand: "BMW",
    rating: 132,
    carName: "BMW X3",
    imgUrl: img03,
    model: "Model-2023",
    price: 5400,
    speed: "20kmpl",
    gps: "GPS Navigation",
    seatType: "Heated seats",
    automatic: "Automatic",
    description:
      " The BMW X3 is a luxury compact SUV that blends exhilarating performance, sophisticated design, and advanced technology, making it a compelling choice for those seeking a refined and engaging driving experience.",
  },

  {
    id: 4,
    brand: "Nissan",
    rating: 112,
    carName: "Nissan Magnite",
    imgUrl: img04,
    model: "Model-2022",
    price: 5000,
    speed: "20kmpl",
    gps: "GPS Navigation",
    seatType: "Heated seats",
    automatic: "Automatic",
    description:
      " The Nissan Magnite is a subcompact SUV that has captured the attention of urban explorers and adventurous spirits alike. Its bold design, impressive performance, and advanced technology make it a compelling choice for those seeking a stylish and practical city companion.",
  },

  {
    id: 5,
    brand: "Toyota",
    rating: 102,
    carName: "Toyota Camry",
    imgUrl: img05,
    model: "Model-2022",
    price: 5000,
    speed: "20kmpl",
    gps: "GPS Navigation",
    seatType: "Heated seats",
    automatic: "Automatic",
    description:
      " The Toyota Camry is a mid-size sedan that has long been synonymous with reliability, comfort, and a refined driving experience. It has consistently been a top-selling car in its segment, appealing to a wide range of drivers seeking a dependable and well-rounded vehicle.",
  },

  {
    id: 6,
    brand: "Mercedes",
    rating: 119,
    carName: "Mercedes-Benz A-Class",
    imgUrl: img06,
    model: "Model-2022",
    price: 7000,
    speed: "20kmpl",
    gps: "GPS Navigation",
    seatType: "Heated seats",
    automatic: "Automatic",
    description:
      " The Mercedes-Benz A-Class is a compact luxury car that embodies a harmonious blend of sophisticated design, advanced technology, and refined performance. It appeals to those seeking a stylish, tech-savvy, and comfortable vehicle that elevates their everyday driving experience.",
  },

  {
    id: 7,
    brand: "Toyota",
    rating: 82,
    carName: "Toyota Glanza",
    imgUrl: img07,
    model: "Model 2023",
    price: 5000,
    speed: "20kmpl",
    gps: "GPS Navigation",
    seatType: "Heated seats",
    automatic: "Automatic",
    description:
      " The Toyota Glanza is a stylish and practical hatchback that offers a blend of affordability, fuel efficiency, and modern features, making it an appealing choice for urban commuters and young drivers seeking a reliable and tech-savvy companion.",
  },

  {
    id: 8,
    brand: "Mercedes",
    rating: 119,
    carName: "Mercedes-Benz A-Class",
    imgUrl: img08,
    model: "Model-2022",
    price: 7000,
    speed: "20kmpl",
    gps: "GPS Navigation",
    seatType: "Heated seats",
    automatic: "Automatic",
    description:
      " The Mercedes-Benz A-Class is a compact luxury car that embodies a harmonious blend of sophisticated design, advanced technology, and refined performance. It appeals to those seeking a stylish, tech-savvy, and comfortable vehicle that elevates their everyday driving experience.",
  },
];

export default carData;
